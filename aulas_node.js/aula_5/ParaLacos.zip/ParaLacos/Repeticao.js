const readline = require("readline-sync");

let num = readline.question('Digite um numero: ')
const rep = readline.question('Quantas repeticoes: ')


for (i = 1; i <= rep; i++){
    console.log(e = (1+1/num)**num)
    num++
}