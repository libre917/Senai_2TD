import "./home.css";


export default function Home() {
  return (
  <>
  <main>
  <img src="/imagem_next.png"></img>
  </main>
  </>
  );
}
