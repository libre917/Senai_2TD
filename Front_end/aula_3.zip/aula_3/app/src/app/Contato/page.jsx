import '../home.css'
export default function Contato(){
    return(
        <main>
        <h1>Contato</h1>
        </main>
    )
}