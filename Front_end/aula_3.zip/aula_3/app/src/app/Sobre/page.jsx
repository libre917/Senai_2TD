import '../home.css'
export default function Sobre(){
    return(
        <main>
        <h1>Sobre</h1>
        </main>
    )
}