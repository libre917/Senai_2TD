import './Footer.css'
export default function Footer(){
    return(
        <footer>
           <p>&copy;Direitos reservados á Lucas Soalheiro</p>
        </footer>
    )
}