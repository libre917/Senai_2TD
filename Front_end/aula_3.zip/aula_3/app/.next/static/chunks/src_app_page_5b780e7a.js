(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_5b780e7a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_5b780e7a.js",
  "chunks": [
    "static/chunks/src_app_home_7c50515e.css"
  ],
  "source": "dynamic"
});
