(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_f38ee402.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_f38ee402.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_ea69acce._.js",
    "static/chunks/src_app_page_module_d12eb71c.css"
  ],
  "source": "dynamic"
});
