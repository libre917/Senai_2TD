create database Produtos;
use Produtos;

create table products(
nome varchar(80) not null,
preco decimal(10,2) not null,
descricao text,
dataHora timestamp not null,
SKU int not null
);

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Monitor',10.5, 'OLED 17', '2025-03-06 14:00:00', '0001');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Teclado',11.5, 'Membrana', '2025-03-06 14:00:00', '0002');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Mouse',12.5, 'DPI 8000', '2025-03-06 14:00:00', '0003');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Mouse Pad',13.5, 'Gamer', '2025-03-06 14:00:00', '0004');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Microfone',14.5, 'Gamer', '2025-03-06 14:00:00', '0005');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Headset',15.5, 'Gamer', '2025-03-06 14:00:00', '0006');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Gabinete',16.5, 'RGB', '2025-03-06 14:00:00', '0007');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Placa Mãe',17.5, 'DDR4', '2025-03-06 14:00:00', '0008');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Placa de Vídeo',18.5, '4090', '2025-03-06 14:00:00', '0009');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Processador',19.5, 'AMD Ryzen 7', '2025-03-06 14:00:00', '0010');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('SSD',20.5, '480 GB', '2025-03-06 14:00:00', '0011');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('HD',21.5, '900 GB', '2025-03-06 14:00:00', '0012');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Memória RAM',22.5, 'DDR4', '2025-03-06 14:00:00', '0013');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Fonte',23.5, '500W', '2025-03-06 14:00:00', '0014');

insert into products (nome,preco,descricao,dataHora,SKU)
values ('Cooler',24.5, 'Refrigerador', '2025-03-06 14:00:00', '0015');

select *from products;

update products
set preco = '40.9'
where nome = 'Fonte';
update products
set preco = '40.9'
where nome = 'Cooler';
update products
set preco = '40.9'
where nome = 'Memória RAM';
update products
set preco = '40.9'
where nome = 'HD';
update products
set preco = '40.9'
where nome = 'SSD';
update products
set preco = '40.9'
where nome = 'Processador';
update products
set preco = '40.9'
where nome = 'Placa de Video';
update products
set preco = '40.9'
where nome = 'Placa Mãe';
update products
set preco = '40.9'
where nome = 'Gabinete';
update products
set preco = '40.9'
where nome = 'Headset';
update products
set preco = '40.9'
where nome = 'Microfone';
update products
set preco = '40.9'
where nome = 'Mouse Pad';
update products
set preco = '40.9'
where nome = 'Mouse';
update products
set preco = '40.9'
where nome = 'Teclado';
update products
set preco = '40.9'
where nome = 'Monitor';
